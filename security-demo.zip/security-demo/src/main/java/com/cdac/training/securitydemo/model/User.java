package com.cdac.training.securitydemo.model;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;

/*
 * UserDetails is a interface that represents a user in the security context. 
 * It contains information such as username, password, and roles, which are 
 * used to authenticate and authorize users in a web application. 
 * Implementations of the UserDetails interface, such as User, 
 * provide methods for retrieving and setting this information. 
 * Spring Security uses instances of UserDetails as the primary building block for 
 * its security model, allowing for flexible and customizable authentication and 
 * authorization.
 */

@Entity
@Table(name="users")
public class User implements UserDetails {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer id;
	@NotEmpty
	private String username;    
	@NotEmpty
	private String password;  
	@NotEmpty
	private String role;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return Collections.singleton(new SimpleGrantedAuthority(role));
	}
	
	

}
