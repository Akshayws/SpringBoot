package com.cdac.training.securitydemo.service;

import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cdac.training.securitydemo.model.User;
import com.cdac.training.securitydemo.repository.UserRepository;

/*
 * The userdetailsservice in Spring Security is used to load user details from 
 * an external data source, such as a database.
 * 
 *  It provides a centralized way to retrieve user information and authenticate users. 
 *  Spring Security offers several implementations of the UserDetailsService, 
 *  including the InMemoryUserDetailsManager and the JdbcUserDetailsManager, 
 *  which can be used to store user details in memory or in a database respectively. 
 *  
 *  This allows for a clean separation of concerns between the authentication process 
 *  and the retrieval of user details.
 */
@Service
public class UserService implements UserDetailsService{
	
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	
	

	public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
		super();
		this.userRepository = userRepository;
		this.passwordEncoder = passwordEncoder;
	}


	public void saveUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword())); //Encrypt password using Bycrypt password encoder
		userRepository.save(user); //save() pre-defined method in JPArepo
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> user=userRepository.findByUsername(username);
		return user.orElseThrow(() -> new UsernameNotFoundException("User Not found"));
	}

}
